ENG
Hello, this activator was made by magg1cc, there are no viruses) check it in the file VirusTotal.jpg or in the link below and there is evidence, good luck bro!

RU
Привет, этот активатор сделал magg1cc, тут нету вирусов) проверь в файле VirusTotal.jpg или по ссылке ниже и там доказательства, удачи бро!

LINK | ССЫЛКА
https://www.virustotal.com/gui/file/0d50331501812cd33dbb2f1ca94279f391488afb3e5d146a21e8105afcdc28fc?nocache=1